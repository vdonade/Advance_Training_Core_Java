package com.mycompany.app;

import java.sql.SQLException;
import java.util.Scanner;
import com.mycompany.dao.ProductManagementDAO;
import com.mycompany.domain.Product;

public class ProductManagementApp {
	public static void main(String[] args) throws ClassNotFoundException, SQLException {
		Scanner sc = new Scanner(System.in);
		while (true) {
			System.out.println("--------------------------------------------------");
			System.out.println("A. View Products");
			System.out.println("B. Add Product");
			System.out.println("C. Update Product");
			System.out.println("D. Delete Product");
			System.out.println("E. Search Product");
			System.out.println("F. Exit");
			System.out.println("==================================================");
			System.out.println("Enter an option");
			System.out.println("==================================================");

			String op = sc.next();

			switch (op) {
			case "A":
				Product p = new Product();
				int row = ProductManagementDAO.viewall(p);
				break;
			case "B":
				System.out.println("------------------------------------------------");
				System.out.println("Enter the Product ID");
				System.out.println("------------------------------------------------");

				Product p1 = new Product();
				p1.setProductId(sc.next());
				System.out.println("-------------------------------------------------");

				System.out.println("Enter the Product Name");
				System.out.println("--------------------------------------------------");

				p1.setProductName(sc.next());
				System.out.println("--------------------------------------------------");

				System.out.println("Enter the Product Price");
				System.out.println("--------------------------------------------------");

				p1.setProductPrice(sc.nextInt());
				ProductManagementDAO crud1 = new ProductManagementDAO();
				int row1 = ProductManagementDAO.insert(p1);
				if (row1 > 0) {
					System.out.println("----------------------------------------------");

					System.out.println("Product added successfully!");
					System.out.println("----------------------------------------------");

				} else {
					System.out.println("----------------------------------------------");

					System.out.println("Fail!!");
					System.out.println("----------------------------------------------");

				}

				break;

			case "C":

				Product p2 = new Product();
				System.out.println("-------------------------------------------------");

				System.out.println("Enter Product ID:");
				System.out.println("-------------------------------------------------");

				p2.setProductId(sc.next());
				System.out.println("-------------------------------------------------");

				System.out.println("Enter New Product Name");
				System.out.println("-------------------------------------------------");

				p2.setProductName(sc.next());
				System.out.println("-------------------------------------------------");

				System.out.println("Enter New Product Price");
				System.out.println("-------------------------------------------------");

				p2.setProductPrice(sc.nextInt());
				ProductManagementDAO crud2 = new ProductManagementDAO();
				int row2 = ProductManagementDAO.update(p2);
				if (row2 > 0) {
					System.out.println("---------------------------------------------");

					System.out.println("Product update successfully! ");
					System.out.println("---------------------------------------------");

				} else {
					System.out.println("Fail!!");

				}
				break;

			case "D":
				System.out.println("Enter the Product ID to be Deleted");
				Product p3 = new Product();
				p3.setProductId(sc.next());
				ProductManagementDAO crud3 = new ProductManagementDAO();
				int row3 = ProductManagementDAO.delete(p3);
				if (row3 > 0) {
					System.out.println("Product deleted successfully! ");
				} else {
					System.out.println("-----------------------------------------------");

					System.out.println("Product Not found!!");
					System.out.println("-----------------------------------------------");

				}
				break;
			case "E":
				System.out.println("---------------------------------------------------");

				System.out.println("Enter the Product ID to be Searched");
				System.out.println("---------------------------------------------------");

				Product p4 = new Product();
				p4.setProductId(sc.next());
				ProductManagementDAO crud4 = new ProductManagementDAO();
				int row4s = ProductManagementDAO.search(p4);

				break;
			case "F":
				System.out.println("*******************Thank You!!********************");
				System.exit(0);
				break;
			default:
			}

		}
	}

}
