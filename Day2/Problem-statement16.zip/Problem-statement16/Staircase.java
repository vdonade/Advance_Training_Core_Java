package Problem_statemen_16;

class Staircase {
	// A simple recursive program to find
	// n'th fibonacci number
	static int fibona(int n) {
		if (n <= 1)
			return n;
		return fibona(n - 1) + fibona(n - 2);
	}

	// Returns number of ways to reach s'th stair
	static int countWays(int s) {
		return fibona(s + 1);
	}

	//Driver program to test above function 
	public static void main(String args[]) {
		int s = 2;
		System.out.println("Number of ways = " + countWays(s));
	}
}
