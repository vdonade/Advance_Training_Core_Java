package Problem_statement_13;

class LinkedList {
	// head of the list
    Node head; 
 
    //Linked List node 
    class Node {
        int data;
        Node next;
        Node(int d)
        {
            data = d;
            next = null;
        }
    }
 
    // Function to get the nth node from the last of a
   //  linked list 
    void printNthFromLast(int n)
    {
        int length = 0;
        Node temp = head;
 
        /// count the number of nodes in Linked List
        while (temp != null) {
            temp = temp.next;
            length++;
        }
 
        // check if value of n is not more than length of
        // the linked list
        if (length < n)
            return;
 
        temp = head;
 
        /// get the (length-n+1)th node from the beginning
        for (int i = 1; i < length - n + 1; i++)
            temp = temp.next;
 
        System.out.println(temp.data);
    }
 
    // Inserts a new Node at front of the list. 
    public void push(int new_data)
    {
       // Allocate the Node & Put in the data
        Node new_node = new Node(new_data);
 
        // Make next of new Node as head 
        new_node.next = head;
 
        // Move the head to point to new Node 
        head = new_node;
    }
 
    //Driver program to test above methods 
    public static void main(String[] args)
    {
        LinkedList list = new LinkedList();
        list.push(22);
        list.push(4);
        list.push(46);
        list.push(25);
 
        list.printNthFromLast(4);
    }
}
