package Problem_statemen_14;

import java.util.*;

class SortAndMerge {

	public static void sortedMerge(int a[], int b[], int res[], int x, int y)

	{
		Arrays.sort(a);

		Arrays.sort(b);

		int i = 0, j = 0, k = 0;

		while (i < x && j < y) {

			if (a[i] <= b[j]) {

				res[k] = a[i];

				i += 1;

				k += 1;

			} else {

				res[k] = b[j];

				j += 1;

				k += 1;

			}

		}

		while (i < x) {

			res[k] = a[i];

			i += 1;

			k += 1;

		}

		while (j < y) {

			res[k] = b[j];

			j += 1;

			k += 1;

		}

	}

	public static void main(String[] args)

	{

		int a[] = { 10, 5, 15 };

		int b[] = { 20, 3, 2 };

		int x = a.length;

		int y = b.length;

		int res[] = new int[x + y];

		sortedMerge(a, b, res, x, y);

		System.out.print("Sorted merged list : {");

		for (int i = 0; i < x + y; i++)

			System.out.print(res[i] + ",");
		System.out.println("}");

	}
}
