package Problem_statement_2_1;

import java.util.Scanner;

class Palindrome
{
	 public static void main(String args[])
	   {
	      String s, reverse = "";
	      Scanner sc = new Scanner(System.in);
	 
	      System.out.println("Enter a string:");
	      s = sc.nextLine();
	 
	      int length = s.length();
	      System.out.println(" Length is : "+s.length());
	      System.out.println(" Uppercase : "+s.toUpperCase());
	 
	      for ( int i = length - 1; i >= 0; i-- )
	    	  reverse = reverse + s.charAt(i);
	 
	      if (s.equals(reverse))
	         System.out.println(s+" is a palindrome");
	      else
	         System.out.println(s+" is not a palindrome");
	      
	   }
}