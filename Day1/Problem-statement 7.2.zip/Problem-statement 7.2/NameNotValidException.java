package Problem_statement_7_2;

public class NameNotValidException extends Exception {
	public String validname()
    {
         return ("Name is not Valid..Please Try again!");
    }

}
