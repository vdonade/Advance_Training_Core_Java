package Problem_statement_1_4;

import java.util.Scanner;

class Rectangle_Modify_Program {
    int length; 
    int width; 
    int area; 
    int parameter;
    
    public int getLength() {
		return length;
	}

	public void setLength(int length) {
		this.length = length;
	}

	public int getWidth() {
		return width;
	}

	public void setWidth(int width) {
		this.width = width;
	}

	
    public Rectangle_Modify_Program()
    {
    	length = 1;
    	width= 1;
    }

    void input() {
        Scanner in = new Scanner(System.in);
        System.out.print("Enter length of rectangle: ");
        length = in.nextInt();
        System.out.print("Enter width of rectangle: ");
        width = in.nextInt();
    }
    
    void  areaRectangle()
    {
        area = length * width;
       
    }
 
     void  perimeterRectangle()
    {
    	 parameter = 2*(length + width);
       
    }

    void display() {
    	if(length>0 && length<20)
        {
        System.out.println("Area of Rectangle = " + area);
        System.out.println("Parameter of Rectangle = " +parameter);}
       
        }

    public static void main(String args[]) {
    	
        Rectangle_Modify_Program ob1 = new Rectangle_Modify_Program();
        ob1.input();
        ob1.areaRectangle();
        ob1.perimeterRectangle();
        ob1.display();
        System.out.println("\n");
        Rectangle_Modify_Program ob2 = new Rectangle_Modify_Program();
        ob2.input();
        ob2.areaRectangle();
        ob2.perimeterRectangle();
        ob2.display();
        System.out.println("\n");
        Rectangle_Modify_Program ob3 = new Rectangle_Modify_Program();
        ob3.input();
        ob3.areaRectangle();
        ob3.perimeterRectangle();
        ob3.display();
        System.out.println("\n");
        Rectangle_Modify_Program ob4 = new Rectangle_Modify_Program();
        ob4.input();
        ob4.areaRectangle();
        ob4.perimeterRectangle();
        ob4.display();
        System.out.println("\n");
        Rectangle_Modify_Program ob5 = new Rectangle_Modify_Program();
        ob5.input();
        ob5.areaRectangle();
        ob5.perimeterRectangle();
        ob5.display();
    	
    }
}
