package Problem_statement_5_1;

public class RegEX {

	static String wordReverse(String st) {
		int i = st.length() - 1;
		int start, end = i + 1;
		String result = " ";

		while (i >= 0) {
			if (st.charAt(i) == ' ') {
				start = i + 1;
				while (start != end)
					result += st.charAt(start++);
				result += ' ';
				end = i;
			}
			i--;
		}
		start = 0;
		while (start != end)
			result += st.charAt(start++);
		return result;
	}

	public static String reverseWord(String st) {
		String words[] = st.split("\\s");
		String reverseWord = "";
		for (String w : words) {
			StringBuilder sb = new StringBuilder(w);
			sb.reverse();
			reverseWord += sb.toString() + " ";
		}
		return reverseWord.trim();
	}

	public static void lengthWord(String st) {
		int sum = 0;
		int len = st.length();
		for (int i = 0; i < len; i++) {
			if (st.charAt(i) == ' ') {
				continue;
			}
			sum++;
		}
		System.out.println("Total length is:" + sum);

	}

	public static void main(String[] args) {

		String st = "JAVA is Simple";

		String new_st = st.toUpperCase();
		System.out.println(new_st);

		String new_st2 = st.toLowerCase();
		System.out.println(new_st2);

		String[] new_st3 = st.split(" ");
		for (int i = 0; i < new_st3.length; i++) {
			String s = new_st3[i];
			System.out.println(s.charAt(0));
		}

		System.out.println(wordReverse(st));
		System.out.println(reverseWord(st));

		lengthWord(st);
	}

}
