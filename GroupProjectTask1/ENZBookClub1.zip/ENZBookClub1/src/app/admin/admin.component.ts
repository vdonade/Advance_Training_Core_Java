import { Router } from '@angular/router';
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-admin',
  templateUrl: './admin.component.html',
  styleUrls: ['./admin.component.css']
})
export class AdminComponent implements OnInit { 
  msg='';
  constructor(private _router:Router) { }

  ngOnInit(): void {
  }
  
  adminId: string;
  Password :string;
  
    adminLogin(){
      if(this.adminId == "admin" && this.Password == "admin123")
      {
        this._router.navigate(['adminsuccess']);
      }
      else {
        alert("Invalid credentials");
      }
    }
}
