import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-adminsuccess',
  templateUrl: './adminsuccess.component.html',
  styleUrls: ['./adminsuccess.component.css']
})
export class AdminsuccessComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
