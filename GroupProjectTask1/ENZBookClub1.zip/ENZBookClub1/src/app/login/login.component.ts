import { User } from './../service/user';
import { RegistrationService } from './../service/registration.service';
import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { Route, Router } from '@angular/router';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
  export class LoginComponent implements OnInit {
    user =new User();
    msg='';
     constructor(private _service:RegistrationService, private _router :Router ) { }
   
     ngOnInit(): void {
     }
   loginuser(){
     this._service.loginUserFromRemote(this.user).subscribe(
       data => {console.log("respone recieved");
       this._router.navigate(['loginsuccess']);
   
     },
     _error => {console.log("exception occured");
     this.msg="Bad credential, please enter valid Email and Password";
    
   
     }
     );
   }
   gotoregistration(){
     this._router.navigate(['/registration']);
   }
   }