export class User {
    id: number;
    emailId: string;
    userName: string;
    password: string;
    cpassword:string;
   
    constructor(){}
    // constructor(id: number, emailId: string, userName: string, password: string) {
    //     // this.emailId=emailId;
    //     // this.id=id;
    //     // this.userName=userName;
    //     // this.password=password;
    // }
}
