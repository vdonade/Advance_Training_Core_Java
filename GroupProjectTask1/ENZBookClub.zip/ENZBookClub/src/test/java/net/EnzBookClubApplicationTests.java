package net;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EnzBookClubApplicationTests {

	@Test
	void contextLoads() {
	}

}
