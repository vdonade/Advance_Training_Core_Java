package net.spring.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import net.spring.model.Product;
import net.spring.service.ProductServices;

@Controller
@RequestMapping
public class ProductController {
	@Autowired
	ProductServices productServices;
	
	//lode add Product form
	@GetMapping("addProduct")
	public String  addProduct()
	{
		
		return "AddProduct";
		
	}
	
	
	//save Product form
	@PostMapping("/insertProduct")
	public String insertProduct(@ModelAttribute("insertProduct") Product Product)
	{
		
		productServices.addProduct(Product);
		return "redirect:/productReport";
	}
	
	
	
	//lode Product data
	@GetMapping("productReport")
	public String loadProduct(Model p)
	{
		p.addAttribute("product", productServices.getAllProduct());
		p.addAttribute("title", "Product Report");
		
		return "ProductReport";
	}
	
	
	//lode edit form
	 
	@GetMapping("/editProduct/{id}")
	public String lodeEditForm(@PathVariable(value="id") int id, Model p)
	{
		Product product=productServices.getById(id);
		
		System.out.println(product);
		p.addAttribute("product", product);
		p.addAttribute("title", "Edit Product");
		
		return "EditProduct";
		
	}
	
	
	
	@PostMapping("/editProduct/updateProduct")
	public String updateProduct(@ModelAttribute("updateProduct") Product product)
	{
		productServices.updateProduct(product);
		
		return "redirect:/productReport";
		
	}
	
	
	
	
	@GetMapping("/deleteProduct/{id}")
	public String deleteProduct(@PathVariable int id)
	{
		productServices.deleteProduct(id);
		
		
		return "redirect:/productReport";
	}
	
	
	
	
	
	
}