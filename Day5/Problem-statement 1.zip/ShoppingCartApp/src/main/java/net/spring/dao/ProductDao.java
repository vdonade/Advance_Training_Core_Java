package net.spring.dao;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.orm.hibernate5.HibernateTemplate;
import org.springframework.stereotype.Component;

import net.spring.model.Product;

@Component
public class ProductDao {

	@Autowired
	HibernateTemplate hiberneteTemplate;
	
	
	//add Product
	@Transactional
	public void addProduct(Product product)
	{
		hiberneteTemplate.save(product);
	}
	
	
	//get all Product
	public List<Product> getAllProduct()
	{
		return hiberneteTemplate.loadAll(Product.class);
	}
	
	//get Product by id
	@Transactional
	public Product getProductById(int id)
	{
		
		
		Product product= hiberneteTemplate.get(Product.class, id);
		return product;
	}
	
	
	//update employee
	
	@Transactional
	public void updateProduct(Product product)
	{
		hiberneteTemplate.update(product);
	}
	
	
	//delete employee
	@Transactional
	public void deleteProduct(int id)
	{
		hiberneteTemplate.delete(hiberneteTemplate.load(Product.class, id));
	}
	
}