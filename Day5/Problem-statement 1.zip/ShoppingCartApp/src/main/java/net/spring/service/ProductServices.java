package net.spring.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import net.spring.dao.ProductDao;
import net.spring.model.Product;



@Component
@Service
public class ProductServices {
	@Autowired
	ProductDao productDao;

	
	
	
	//add Product
	public void addProduct(Product product)
	{
		productDao.addProduct(product);
	}
	
	//get all Product
	public List<Product> getAllProduct()
	{
		return productDao.getAllProduct();
	}
	
	
	//get Product by id
	
	public Product getById(int id)
	{
		return productDao.getProductById(id);
	}
	
	
	// update Product
	
	public void updateProduct(Product product)
	{
		productDao.updateProduct(product);
	}
	
	
	//delete Product 
	
	public void deleteProduct(int id)
	{
		productDao.deleteProduct(id);
	}
	
}