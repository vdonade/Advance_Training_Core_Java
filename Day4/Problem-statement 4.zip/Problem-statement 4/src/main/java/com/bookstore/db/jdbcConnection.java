package com.bookstore.db;

import java.sql.Connection;
import java.sql.DriverManager;

public class jdbcConnection {
	
private static Connection connection;
	
	public static Connection getConnection() {
		try {
			if(connection==null) {
				Class.forName("com.mysql.jdbc.Driver");
				connection=(Connection) DriverManager.getConnection("jdbc:mysql://localhost:3306/bookshop","root","password");
			}
			
		}
		catch(Exception e){
			e.printStackTrace();
		}
		return connection;
	}
}
